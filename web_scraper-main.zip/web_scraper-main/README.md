# web_scraper
Web scraper built for Summer Smash Tennis to gather information from ActiveNet to update registration information.

The authorization key to our actual spreadsheet has been removed from the script in case of outside parties updating our sheet.
